#include "com_example_pllab_ndk_mal_app_JNIClass.h"

#include <stdio.h>
#include <string.h>
#include <jni.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <stdlib.h>


#define PORT "9190"
#define SERVER_DOMAIN "164.125.34.105"

void error_handling(char *);

JNIEXPORT jint JNICALL Java_com_example_pllab_ndk_1mal_1app_JNIClass_sendInfoIntager (JNIEnv *a, jobject b, jint num)
{
    printf("%d", num);
    return num;
}

JNIEXPORT jstring JNICALL Java_com_example_pllab_ndk_1mal_1app_JNIClass_sendInfoString (JNIEnv *a, jobject b, jstring str)
{
    int sock;
    FILE* writeFP;

    const char* message = (*a)->GetStringUTFChars(a, str, NULL);
    struct sockaddr_in serv_addr;

    jstring result;
    result = (*a)->NewStringUTF(a, message);

    sock = socket(PF_INET, SOCK_STREAM, 0);
    if (sock == -1) {
        error_handling("socket() error");
    }

    writeFP = fdopen(sock, "w");

    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = inet_addr(SERVER_DOMAIN);
    serv_addr.sin_port = htons(atoi(PORT));


    if (connect(sock, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) == -1) {
        error_handling("connect() error");
    }
    fputs(message, writeFP);
    fclose(writeFP);

    return result;

}

void error_handling(char *message)
{
    fputs(message, stderr);
    fputc('\n', stderr);
    exit(1);
}