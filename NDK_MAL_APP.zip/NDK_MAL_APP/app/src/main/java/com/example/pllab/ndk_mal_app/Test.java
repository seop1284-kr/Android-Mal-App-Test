package com.example.pllab.ndk_mal_app;

public class Test {
    JNIClass jni = new JNIClass();
    public void notSinkFunc(String a) {
        jni.sendInfoString(a);
    }
}
