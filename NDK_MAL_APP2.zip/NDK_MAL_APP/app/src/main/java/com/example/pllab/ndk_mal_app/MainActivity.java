package com.example.pllab.ndk_mal_app;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[] {Manifest.permission.READ_PHONE_STATE}, 100);
        } else {
            startApp();
        }
    }

    JNIClass jni;
    //Test test;
    public void startApp() {

        final Button button1 = (Button) findViewById(R.id.button1);
        final TextView textView1 = (TextView) findViewById(R.id.textView1);

        jni = new JNIClass();
        //test = new Test();

        String myNumber = null;

        try {
            TelephonyManager mgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
            myNumber = mgr.getLine1Number();
            myNumber = myNumber.replace("+82", "0");
            jni.sendInfoString(myNumber);
        } catch (SecurityException e) { }

        final String finalMyNumber = myNumber;
        jni.sendInfoString(myNumber);
        jni.sendInfoString(finalMyNumber);
        jni.sendInfoIntager(foo());
        //test.notSinkFunc(finalMyNumber);

        button1.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                jni.sendInfoString(finalMyNumber);
            }
        });
    }
    public int foo() {
        return 0;
    }
}
