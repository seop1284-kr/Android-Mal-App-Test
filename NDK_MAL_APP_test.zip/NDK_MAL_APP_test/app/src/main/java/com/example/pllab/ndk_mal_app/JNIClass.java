package com.example.pllab.ndk_mal_app;

public class JNIClass {
    static
    {
        System.loadLibrary("example");
    }

    public native String sendInfoString(String str);

}