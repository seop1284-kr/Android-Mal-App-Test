package com.example.pllab.ndk_mal_app;

public class TestClass {
    public String sendInfoString(String num) {
        return num;
    }
}
